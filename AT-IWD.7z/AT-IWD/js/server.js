document.getElementById("btnEntrar").addEventListener("click", function () {
    const usuario = document.getElementById("usuario").value;
    const senha = document.getElementById("senha").value;
    const status = document.getElementById("status");

    if (usuario === "admin" && senha === "123") {
        status.className = "alert alert-success";
        status.textContent = "Login realizado com sucesso!";
        status.classList.remove("d-none");
           } 
    else {
        status.className = "alert alert-danger";
         status.textContent = "Usuário ou senha incorretos.";
         status.classList.remove("d-none");
        }
       });